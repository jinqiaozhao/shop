<template>
	<div class="box">
		<div class="show">
			<!-- <img src="../../assets/decorate/leeksteward/leek_02.jpg" /> -->
			<img src="../../assets/decorate/bby_active_1.jpg" alt="banner图片" style="width:100%;"/>
			<img src="../../assets/decorate/leeksteward/leek_03.jpg" />
			<img src="../../assets/decorate/leeksteward/leek_04.jpg" />
			<img src="../../assets/decorate/leeksteward/leek_05.jpg" />
			<img src="../../assets/decorate/leeksteward/leek_06.jpg" />
		</div>
	</div>
</template>
<script>
</script>

<style scoped lang="less">
.show{
	img {
		float: left;
		width: 7.5rem;
	}
}
</style>
