/*
*作者---杨彬
*
*/
<template>
  <div >
    <!--<cake-nav :navData="sData.myOrder.navText" ></cake-nav>-->
    <div style="text-align: center;padding:0.1rem;background-color: #fff;display: flex;"><img src="../../assets/back.png" alt="" style="flex:0.03;" @click="$router.go('-1')">  <span style="flex:0.9;line-height: 0.6rem;font-size:0.35rem;">售后申请</span></div>
    <section class="order-content">
      <div class="this-splace"></div>
      <div class="order-item" v-for="(nitem,nindex) in listData">
        <p class="item-title-warp">
          <span class="orderNo-text" v-text="sData.myOrder.orderNumberCn"></span>
          <span class="orderNo-number" v-text="nitem.sn"></span>
        </p>
        <div class="item-content-warp" v-for="mitem in nitem.items" >
          <img :src='mitem.thumbnail'@click="goGoodsDetail(nitem)">
          <div class="cn-text-warp" >
            <p class="product-title" v-text="mitem.name"></p>
            <p style="font-size:0.15rem;color:#8D8D8D;">数量:{{mitem.quantity}}</p>
          </div>
          <div style="display:flex;position:relative;">
            <p style="flex:1;font-size:0.15rem;color:#8D8D8D;" v-if="false">该商品已超过售后期 </p>
            <p style="flex:1;" v-if="true"> </p>
            <p style="font-size:0.15rem;color:#8D8D8D;padding:0.1rem;border:1px solid #fb4874;color:#fb4874;" @click=goAfterSale(mitem.id)>申请售后 </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
<script type="text/javascript">
  import cakeNav from "src/components/com/nav/nav.vue";
  export  default {
    props: ["sData"],
    components: {cakeNav},
    data(){
      return {
        route:this.$route.params.id,
        isGroup:[],
        defaultData: [
          // {status:"0",id:"232321111222",money:"3600.00",title:'华为Mate9 4GB+32GB版',
          //   detail:'颜色:月光银',img:[1]},
          // {status:"1",id:"232321111222",money:"3600.00",title:'华为Mate9 4GB+32GB版',
          //   detail:'颜色:月光银',img:[1,2]},
          // {status:"2",id:"232321111222",money:"3600.00",title:'华为Mate9 4GB+32GB版',
          //   detail:'颜色:月光银',img:[1]},
          // {status:"3",id:"232321111222",money:"100",title:'华为Mate9 4GB+32GB版',
          //   detail:'颜色:月光银',img:[1,2]}
        ],
        listData: []
      }
    },
    methods: {
      goAfterSale(id){
        window.location.href=(`#/aftersales/${id}`)
      },
      getData(status){
        if (status == -1) {
          status = ''
        } else if (status == 0) {
          status = 0
        } else if (status == 3) {
          status = 1
        } else if (status == 6) {
          status = 3
        }
        this.listData = [];
        this.postAjax(this.sData.url.orderUrl, {status: status}, (res) => {
          if(res.code==200){
          this.listData = res.data.data
        }
      })
      },
      goGoodsDetail(nitem){
        window.location.href = (`#/orderDetail/${nitem.id}`);
      }
    },
    created(){
      m$.documentTitle("售后申请");
      this.getData(6)
      this.route=this.$route.params.id
    },
    updated(){

    },
    watch: {
      '$route': function (val) {
        this.getData(val.params.id);

        this.route=this.$route.params.id
        var sn=this.listData.sn;
      }
    },
  }
</script>
<style scoped lang="less">
  .this-splace{
    height: 0.2rem;
    background-color: #ECECEC;
  }

  .order-content{
    background-color: #ECECEC;
    .order-item{

      margin-bottom: 0.2rem;
      background-color: #ffffff;
      >*{
        padding: 0 0.2rem;
      }
      .item-title-warp{
        position: relative;
        width: 100%;
        height: 0.8rem;
        border-bottom: 1px dashed #d3d3d3;
        font-size: 0;
        text-align: left;
        line-height: 0.8rem;
        >span{
          vertical-align: middle;
          font-family:PingFangSC-Regular;
          font-size:0.3rem;
          color:#494949;
          letter-spacing:0px;
          text-align:left;
        }
        .order-type{
          color:#fb4874;
          right: 0.35rem;
        }
      }
      .item-content-warp{
        font-size: 0;
        padding-bottom: 0.15rem;
        >*{
          vertical-align: middle;
          margin-top: 0.15rem;
        }
        img{
          width: 1.1rem;
          height: 1.1rem;

          margin-right: 0.15rem;
        }
        .cn-text-warp{
          display: inline-block;
          max-width: 5.3rem;
          font-size: 0;
          .product-title{
            font-family:PingFangSC-Regular;
            font-size:0.28rem;
            color:#222222;
            letter-spacing:0px;
            line-height: 100%;
            text-align:left;
            margin-bottom: 0.1rem;
          }
          .product-detail{
            font-family:PingFangSC-Regular;
            font-size:0.28rem;
            color:#8d8d8d;
            letter-spacing:0px;
            line-height:0.36rem;
            text-align:left;
          }
        }
      }
      .item-price{
        position: relative;
        border-top: 1px dashed #e3e3e3;
        border-bottom: 1px solid #e3e3e3;
        height: 0.8rem;
        line-height: 0.8rem;
        font-size: 0;
        text-align: right;
        >span{
          vertical-align:middle;
        }
        .money-cn{
          position: absolute;
          left:0.2rem;
          top:0.2rem;
          font-family:PingFangSC-Regular;
          font-size:0.28rem;
          color:#474747;
          letter-spacing:0px;
          line-height:0.28rem;
          text-align:center;
        }
        .money-warp{
          position: absolute;
          left:3.2rem;
          top:0.2rem;
          font-family:PingFangSC-Regular;
          font-size:0.24rem;
          color:#222222;
          letter-spacing:0px;
          line-height:0.28rem;
          text-align:right;
          >span{
            font-size:0.28rem;
          }
        }
      }
      .item-operation{
        height: 0.9rem;
        line-height: 0.9rem;
        font-size: 0;
        text-align: right;
        padding: 0 0 0 0.2rem;
        >button{
          border:1px solid #fb4874;
          border-radius:0.1rem;
          width:1.56rem;
          height:0.6rem;
          vertical-align: middle;
          font-family:PingFangSC-Regular;
          font-size:0.3rem;
          color:#fb4874;
          letter-spacing:0px;
          line-height:0.6rem;
          text-align:center;
          background-color: transparent;
          margin-right: 0.2rem;
          &:last-of-type{
            background:#fb4874;
            color: #ffffff;
          }
        }
      }
    }

  }

</style>
