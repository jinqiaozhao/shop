/*
*作者---杨彬
*
*/
<template>
  <div>
    <header class="detail-head">
      <span v-text="sData.myOrder.orderNumberCn+' '"></span>
      <span v-text="defaultData.sn"></span>
      <span class="order-type com-div-middle-ab"
            v-text="sData.myOrder.type[defaultData.status].name"></span>
    </header>
    <section>

      <div class="content-warp">
        <div class="content-item-warp" v-for='(ii,index) in goods'>
          <img :src="ii.thumbnail">
          <div class="content-item" :class="{imgAccountMore:defaultData.img.length>1}">
            <p class="title" v-text="ii.name"></p>
            <p class="detail" v-text="ii.digest"></p>
            <p class="detail" v-text="ii.specificationName" v-if="ii.specificationName"></p>
          <p class="money"
             v-text="sData.myOrder.detail.rmb+ii.price"></p>
          <p class="number"
             v-text="sData.myOrder.detail.textOther[0]+ii.quantity"></p>
          </div>
          <div class="after A" v-if="apply" @click='afterOK(ii.id,index)'>申请售后</div>
          <div class="after X" v-if="underway" @click='cancel()'>取消申请</div>
        </div>
      </div>
			
  <div class="SQselect" v-if="selectshow">
  	<div class="top">
  		确定要取消申请售后么？
  	</div>
  	<div class="bottom">
  		<div class="cancel" @click='bottomcancel()'>取消</div>
  		<div class="affirm">确定</div>
  	</div>
  </div>
			
    </section>

  </div>
</template>
<script type="text/javascript">
  export  default {
    props:['sData'],
    data(){
      return{
        defaultData:
          { sendTime:"2017-1-11 10:00~11:00",
            orderTime:"2017-01-11 10:00",
            remark:"请尽快配送",
            number:5,
            status:"1",id:"232321111222",
            leftTime:'00:30:59',
            money:"100",title:'华为Mate9 4GB+32GB版',
            detail:'月光银',
            img:[1], freight:20,point:100,coupon:20,
            address:'四川省成都市双流县华阳镇街道龙灯山路一段名著司南1栋1单元011',tel:'18202830089',name:'张虹'
          },
        selectshow:false,
        underway:false,
        apply:true,
        productId:'',
        goods:[],
        sendType:'',
        sendSn:'',
        payType:'',
        mark:'',
        gtTime:'',
        timer:'',
        leftTime:'',
        leftTimeFlag:false,
        fun1:function (aindex) {
          return (aindex==0 ? this.sendType :
              (aindex==1 ? this.sendSn :
                (aindex==2?this.payType:(aindex==3?this.mark:(aindex==4?this.gtTime:""))))
          )
        },
        funMoney:function (aindex) {
          return (aindex==0 ? this.defaultData.totalAmount:
              (aindex==1 ? this.defaultData.freight :
                  (aindex==2 ? this.defaultData.pointsValue/100 :
                      (aindex==3?this.defaultData.couponAmount:"")
                  )
              )
          )
        },
        fun:function (aindex) {
          return (aindex==0 ? this.sendType :
              (aindex==1 ? this.mark :
                (aindex==2?this.gtTime:""))
          )
        },
      }
    },
    methods:{
    bottomcancel(){this.selectshow = false;},
    cancel(){
    	this.selectshow = true;
    },
	  afterOK(id,index){
	  	if(id=='00'&&index=='00'){
	  		 m$.template({
          val:'正在售后处理中...',
          time:1000
        });
	  		return;
	  	}
    	m$.sessionStores.set('index',index);
	  	window.location.href=(`#/aftersales/${id}`)
	  },

    },
    created(){
    	m$.sessionStores.set('order',this.$route.params.id);
      m$.documentTitle("订单详情");
      this.postAjax(this.sData.url.orderDetailsUrl,{orderId:this.$route.params.id},(res)=>{
        console.log(res.data)
      this.productId 						=   res.data.items;//商品ID
      this.defaultData.address            =   res.data.address//地址
      this.defaultData.id                 =   res.data.id//订单号
      this.defaultData.sn                 =   res.data.sn//订单号
      this.defaultData.name               =   res.data.receiverName//姓名
      this.defaultData.receiverMobile     =   res.data.receiverMobile//电话
      this.defaultData.status             =   res.data.status//订单状态
      this.defaultData.totalAmount         =   res.data.totalAmount//实付款
      this.defaultData.paidAmount         =   res.data.paidAmount//实付款
      this.defaultData.number             =   res.data.quantity//实际数量
      this.defaultData.freight            =   res.data.freight//运费
      this.defaultData.pointsValue            =   res.data.pointsValue//
      this.defaultData.couponAmount       =   (res.data.couponAmount===null)?'0':res.data.couponAmount//优惠
      this.goods                          =   res.data.items//商品图片等信息
      this.sendType                       =   res.data.shippingMethod?res.data.shippingMethod:"暂无";//配送方式
      // this.sendType                       =   '快递';//配送方式
      this.sendSn                         =   res.data.shippingSn?res.data.shippingSn:'暂无';//运单号
      this.payType                        =   res.data.payMethod;//支付方式
      this.mark                           =   res.data.remark;//运单备注
      this.gtTime                         =   res.data.gmtCreate;//下单时间
      
      if(res.data.currentDate&&res.data.gmtCreate){
        var currentDate = new Date(res.data.currentDate.replace(
          /\-/g,'/'));
        var gmtStart = new Date(res.data.gmtCreate.replace(
          /\-/g,'/'));
        var time = (gmtStart.getTime()+1800000 - currentDate.getTime()) / 1000;
        if(time<0){
          return;
        }
        //获得 秒杀结束时间
        var _this = this;

        _this.timer = setInterval(function () {
          _this.leftTimeFlag=true;
          time--;
          if(time==0){
            _this.leftTimeFlag=false;
            clearInterval(_this.timer);
            _this.leftTime='00:00:00'
          }
          _this.formatSeconds(time);
        }, 1000)
      }

    })
	console.log(this.goods)
    }
  }
</script>
<style scoped lang="less">
//申请取消弹窗
.SQselect{
	position: fixed;
	top: 30%;
	left: 18%;
	border: 1px solid #8D8D8D;
	font-size: .25rem;
	width: 4.8rem;
	height: 2.5rem;
	text-align: center;
	line-height: 1.5rem;
	border-radius: 10px;
	.top{
		height: 1.9rem;
	}
	.bottom{
		height: .56rem;
		border-top: 1px solid #C2C2C2;
		display: flex;
		line-height: .56rem;
		.cancel{
			width: 50%;;
			border-right: 1px solid #C2C2C2;
		}
		.affirm{
			border-radius:0 0 10px 0;
			width: 50%;
			background-color: red;
			color: #FFF;
		}
		
	}
}

header{
  line-height: 0.88rem;
  height: 0.88rem;
  padding: 0 0.2rem;
  font-family:PingFangSC-Regular;
  font-size:0.3rem;
  color:#222;
  letter-spacing:0px;
  text-align:left;
  position: relative;
  background-color: #ffffff;
  >span{
    font-size:0.3rem;
    letter-spacing:0px;
    text-align:left;
  }
  .order-type{
    font-family:PingFangSC-Regular;
    font-size:0.3rem;
    letter-spacing:0px;
    text-align:right;
    right: 0.35rem;
    color:#fb4874;
  }
}
section{
  background-color: #ECECEC;
  padding-top: 0.2rem;
  >div{
    margin-bottom: 0.2rem;
    &:last-of-type{
      margin-bottom: 0;
    }
    border-bottom: 1px solid #e3e3e3;
    border-top: 1px solid #e3e3e3;
    background-color: #ffffff;
  }

  .content-warp{
  padding-left: 0.2rem;
	.after{
		position: absolute;
		right: .2rem;
		top: 1.7rem;
		height: .5rem;
		width: 1.4rem;
		border-radius:5px;
		text-align: center;
		font-size: .3rem;
	}
	.A{ background-color: #FB4874;border: 1px solid red;color: #FFF;}
	.X{ border: 1px solid #7B7B7B;color:#4E4E4E}
    .content-item-warp{
      padding: 0.3rem 0 0.3rem 0.15rem;
      position: relative;
      border-bottom:1px solid #e3e3e3 ;
      &:last-of-type{
        border-bottom: none;
      }
      font-size: 0;
      >img{
        width:1.9rem;
        height: 1.9rem;
        margin-right:0.2rem ;
        &:last-of-type{
          margin-right: 0;
        }
      }
      >*{
        vertical-align: middle;
      }
      .content-item{
        &.imgAccountMore{
          margin-top: 0.2rem;
        }
        font-size: 0;
        margin-left: 0.2rem;
        max-width: 4.53rem;
        display: inline-block;
        min-height: 1.62rem;
        _height: 1.62rem;
        .title{
          font-family:PingFangSC-Regular;
          font-size:0.28rem;
          color:#222222;
          letter-spacing:0px;
          line-height:0.28rem;
          text-align:left;
          margin-bottom: 0.1rem;
          overflow : hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        .detail{
          font-family:PingFangSC-Regular;
          font-size:0.26rem;
          color:#8d8d8d;
          letter-spacing:0px;
          line-height:0.36rem;
          text-align:left;
          overflow : hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
        }
        display: inline-block;
      }
      .money,.number{
      	margin: .1rem 0 0 0;
        font-family:PingFangSC-Regular;
        font-size:0.32rem;
        color:#000000;
        letter-spacing:0px;
        line-height:0.32rem;
      }
      .money{
        left: 2.25rem;
        color:#fb4874;
      }
      .number{
      	margin-left: .1rem;
        right: 0.35rem;
      }
    }
  }

}


  .menu{
    border: 1px red solid;
    background-color: #FFF;
    position: fixed;
    height: 40px;width: 100%;
    bottom: 0;
  }
  .menu-one{
    font-size: .3rem;
    border: 1px red solid;
    text-align: center;
    border-radius: 10px;
    width: 1.5rem;
    display: inline-block;
  }
</style>
