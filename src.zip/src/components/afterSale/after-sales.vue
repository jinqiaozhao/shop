<template>
	<div class="box">
  <div style="text-align: center;padding:0.1rem;color:#939393;box-shadow:0px 5px 10px #000;">本次售后服务由<span style="color:#E98782;">宝宝余</span>为您服务</div>
		<div class="goods">
			<div class="imgs"><img :src="goods.thumbnail"></div>
			<div class="text">
				<div class="name">{{goods.name}}</div>
				<div class="price">价格：￥{{goods.productPaidPrice}}</div>
				<div class="quantity">数量：X{{goods.quantity}}</div>
			</div>
		</div>
		<!-- <div class="odd">
			<span>选择单号:</span>
			<select class="select-odd">
				<option></option>
			</select>
		</div> -->

		<div class="type">
			<span>服务类型</span>
			<div class="select-type">
				<div @click='butselect(1)' v-bind:class="{ 'butcs': service==1 ,'but': service!=1}">退货</div>
				<div @click='butselect(2)' v-bind:class="{ 'butcs': service==2 ,'but': service!=2}">换货</div>
        <div @click='butselect(3)' v-bind:class="{ 'butcs': service==3 ,'but': service!=3}">维修</div>
			</div>
		</div>
		<div class="cause">
			<span>问题描述</span>
			<textarea placeholder='请您在此描述问题' v-model='issue'>
			</textarea>
			<div class="imgshow" v-if=''>
                  <div class="img-frame" v-for='(item,index) in Images'>
                  	<img class="imgXX" src="http://ovn5haih3.bkt.clouddn.com/%E5%8F%89.png" @click="delImg(index)"/>
                  	<div class="frame">
                  		<img :src="item.url">
                  	</div>
                  </div>
			</div>
			<div class="updataimg">
				<img src="http://ovn5haih3.bkt.clouddn.com/%E7%9B%B8%E6%9C%BA%20%284%29.png" />
				<div class="updataimgD">
					<input  name="wwf" id="d1" type="file" @change="upDateImg('#d1')" accept="image/*" >
				</div>
			</div>
		</div>
		<div class="menu">
			<div>姓&nbsp&nbsp&nbsp&nbsp名：<input type="text"  v-model='username' /></div>
			<div>手机号码：<input type="text"  v-model='cellphone' /></div>
		</div>
		<div class="span">提交服务单后，售后专员可能与您电话沟通，请保持手机通畅</div>
		<div class="ok" @click='Dataupdate()'>提交</div>
	</div>
</template>
// http://www.cnblogs.com/zhengweijie/p/6902957.html
<script>

export default{
    props:['sData'],
    name: 'accident',
    data(){
       return{
        goods:'',
        service:'',
        issue:'',
        username:'',
        cellphone:'',
        orderID:'',
        goodsID:this.$route.params.id,
        goodsindex:'',
        Images: [],
       }
    },
    methods:{
    delImg(val){
    	console.log(this.Images)
    	console.log(val)
    	this.Images.splice(val,1)
    },
    butselect(index){
    	this.service=index;
   	},
    upDateImg(oid){
    	console.log(this.Images.length)
    	if(this.Images.length<4){
    		var _this = this;
		    m$.dealImage(true, m$.dom('#d1')[0].files[0], {width: 500, height: 500, quality: 0.8},
		    function (rr) {
		        var imgObj = {};
		        imgObj.url = rr;
		        _this.Images.push(imgObj);
		        console.log(_this.Images)
		    })
    	}else{
    		 m$.template({
                val:'图片已经达到上限',
                time:1000
            });
    	}
   	},

    Dataupdate(){
    	console.log(this.service,this.issue,this.username,this.cellphone)
    	if(!this.service){
            m$.template({
                val:'请选择服务类型',
                time:1000
            });
            return
    	}
    	if(!this.issue){
            m$.template({
                val:'请输入问题描述',
                time:1000
            });
            return
    	}
    	if(!this.username){
            m$.template({
                val:'请输入姓名',
                time:1000
            });
            return
    	}
    	if(!this.cellphone){
            m$.template({
                val:'请输入手机号码',
                time:1000
            });
            return
    	}
    	m$.template({
            val: '提交中...',
            time: 1000
        });
        console.log(this.service,this.issue,this.username,this.cellphone)
    },
    orderDetailsUrl(){
        this.postAjax(this.sData.url.orderDetailsUrl,{orderId:this.orderID},(res)=>{
        	if(res.code==200){
        		console.log('订单',res.data)
        		this.goods = res.data.items[this.goodsindex];

        	}
        	console.log(res.code)
        })
   	},
   	},
    created(){
      m$.documentTitle("申请售后服务");
      this.orderID = m$.sessionStores.get('order')
      this.goodsindex = m$.sessionStores.get('index')
      console.log(this.goodsindex);
      console.log(this.orderID,this.goodsID)
      this.orderDetailsUrl()
  	}
}
</script>

<style lang="less" scoped>

	.updataimg{
		position: relative;
		img{
			position: absolute;
			width: .6rem;
    		height: .6rem;
		}
		.updataimgD{
		    >input{
				width: .6rem;
				border: 1px solid red;
    			z-index: 5;
    			height: .6rem;
    			opacity: 0;
			}
		}
	}
	.butcs{
		border: 1px solid #E98782;
		color: #DD3D33;
		display: inline-block;
		height: .65rem;
		line-height: .65rem;
		border-radius: 2px;
		padding:0 .25rem 0 .25rem;
	}
	.goods{
		padding: .2rem 0 0 .35rem;
		width: 100%;
		background-color: #FFF;
		display: flex;
		margin-bottom: .05rem;
		.imgs{
			width: 1.87rem;
			height: 1.87rem;
			//border: 1px solid #939393;
			padding:1px;
			img{
				width: 1.6rem;
			//	height: 1.8rem;
				border: 1px solid #939393;
			}
		}
		.text{
			margin:.2rem 0 0 .2rem;
			width: 5rem;
			height: 1.54rem;
			.name,.price,.quantity{
				width: 5rem;
				line-height: .5rem;
				height: .5rem;
			}
			.name{
				font-size: .3rem;
				margin-bottom: 0;
			    text-overflow: ellipsis;
			    overflow: hidden;
			    display: -webkit-box;
			    -webkit-box-orient: vertical;
			    -webkit-line-clamp: 1;
			    min-height: .25rem;
			}
			.price{
				font-size: .25rem;
				color: #E98782;
			}
			.qiantity{

			}
		}
	}

	.odd,.type,.cause,.menu{
		padding: .2rem .2rem .2rem .3rem;
		background-color: #FFF;
		margin-bottom: .05rem;
	}
	.box{
		font-family: "黑体";
		font-size: .28rem;
		.span{
			font-size: .2rem;
			text-align: center;
			color: #939393;
			margin: .25rem 0 .4rem 0;
			}
		.ok{
			margin-left: 2.225rem;
			color: #FFF;
			height: .65rem;
			width: 3rem;
			border-radius: 5px;
			text-align: center;
			line-height: .65rem;
			background-color: #DF443B;
		}
		.odd{
			>select{
				width: 5rem;
			}
		}
		.type{
			.select-type{
				padding-top: .15rem;
			}
			.but{
				display: inline-block;
				height: .65rem;
				line-height: .65rem;
				border: 1px solid #8E8E8E;
				color: #575757;
				border-radius: 2px;
				padding:0 .45rem 0.25rem;
			}
		}
		.cause{
			>span{display:block}
			>textarea{
				padding: .2rem;padding-left: .3rem;
				margin-top: .15rem;
				width: 6.8rem;height: 2.2rem;
				background-color: #F8F8F8;
				font-size: .2rem;
			}
			.imgshow{
				margin-top: 1px;
				border: 1px solid #CFCFCF;
				width: 6.8rem;
				.img-frame{
					position: relative;
					.imgXX{
						width: .45rem;height: .45rem;
						position: absolute;right: -.2rem;
					}
					margin: 0 .1rem .1rem .08rem;
					display: inline-block;
					width:22%;
					height:1.8rem;
					.frame{
						margin-top: .16rem;
						width: 1.6rem;height:1.6rem;
						border: 1px solid #727272;
						padding: 1px;
						>img{
							border: 1px solid #575757;
							max-height: 100%;
							max-width: 100%;
						}
					}
				}
			}
		}
		.menu{
      padding:0;
			>div{
        color:#6A6A6A;
				display: block;
        border-bottom:1px solid #E1E3E7;
        padding:0.2rem;
				>input{
					background-color: #fff;
					width: 5rem;
					height: .36rem;

				}
			}
		}
	}
</style>
